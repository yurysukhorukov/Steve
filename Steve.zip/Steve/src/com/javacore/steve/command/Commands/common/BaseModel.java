package com.javacore.steve.command.Commands.common;

public abstract class BaseModel {
}
