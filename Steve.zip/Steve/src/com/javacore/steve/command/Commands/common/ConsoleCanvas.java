package com.javacore.steve.command.Commands.common;

public class ConsoleCanvas extends Canvas {
    @Override
    public void drawText(String text) {
        System.out.println(text);
    }

    public void drawSquare(int size){
        if (size < 2) {
            System.out.println("No square");
        }
        System.out.println("\n");
        for (int i = 0; i < size; i++) {
            System.out.print("#");
        }
        for (int i = 0; i < size; i++) {
            System.out.print("#");
        }

    }
}
