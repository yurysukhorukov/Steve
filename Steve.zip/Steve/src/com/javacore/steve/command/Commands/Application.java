package com.javacore.steve.command.Commands;

import com.javacore.steve.command.Commands.Commands.ACommand;
import com.javacore.steve.command.Commands.Commands.CommandRegistry;
import com.javacore.steve.command.Commands.profile.ProfileController;
import com.javacore.steve.command.Commands.profile.ProfileModel;
import com.javacore.steve.command.Commands.profile.ProfileView;

public class Application {

    static public final String APP_NAME = "Steve";
    static public final String AUTHOR = "Sukhorukov Yury";
    static public final String VERSION = "0.0.0";

    public static void main(String[] args){
        ProfileController profileController = new ProfileController();
        profileController.showProfile(1);

        System.out.println("Hello my name is " + APP_NAME);
        System.out.println("My author is " + AUTHOR);
        String commandName = "version";
        ACommand command = CommandRegistry.INSTANCE.getCommand(commandName);
        command.execute();
        commandName = "author";
        command = CommandRegistry.INSTANCE.getCommand(commandName);
    }
}
